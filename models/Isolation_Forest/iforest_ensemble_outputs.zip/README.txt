Isolation Forest — ensemble inputs

Run all cells with train_scaled.csv, val_scaled.csv, cal_scaled.csv, dataset2_eval.csv uploaded to Colab.

Model training: train_scaled.csv exclusively; three independently fitted 200-tree Isolation Forest models (random seeds 0, 1, 2).

Score definition: -IsolationForest.score_samples, higher indicates more anomalous; no alarm threshold or binary alarms are used.

Scores: scores/iforest_scores_train.csv, scores/iforest_scores_val.csv, scores/iforest_scores_cal.csv, scores/iforest_scores_dataset2.csv. Each file includes DATETIME, score_seed0, score_seed1, score_seed2, score_mean. Timestamps preserve source row order.

Models: models/iforest_seed0.joblib, iforest_seed1.joblib, iforest_seed2.joblib. Load with joblib.load(path)['model'] and pass features exactly in manifest.json order. Files require a trusted source and a compatible scikit-learn environment.

threshold_free_metrics.csv reports ROC-AUC and average precision on Dataset 2, using reconstructed labels solely for evaluation. No classification threshold, F1 or confusion matrix is reported here.

Ensemble: align by DATETIME; avoid training or tuning ensemble weights using Dataset 2 labels if Dataset 2 is also the evaluation set. Use val/cal inputs for score calibration without attacks; a separately labeled development set is needed for supervised ensemble weight fitting.
